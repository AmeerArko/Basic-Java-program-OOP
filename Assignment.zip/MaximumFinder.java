public class MaximumFinder {

    public static void main(String[] args) {

        int[] arr1 = {3, 1, -5, 10};
        int[] arr2 = {-2, 6, 7, 8, 0};
        int[] arr3 = {12, -6, 4, 2, 1};
        int[] arr4 = {10, 5, 9, 18, 7};


        Thread thread1 = new MaximumFinderThread(arr1);
        Thread thread2 = new MaximumFinderThread(arr2);
        Thread thread3 = new MaximumFinderThread(arr3);
        Thread thread4 = new MaximumFinderThread(arr4);


        thread1.start();
        thread2.start();
        thread3.start();
        thread4.start();

        try {

            thread1.join();
            thread2.join();
            thread3.join();
            thread4.join();


            int max1 = ((MaximumFinderThread) thread1).getMaximum();
            int max2 = ((MaximumFinderThread) thread2).getMaximum();
            int max3 = ((MaximumFinderThread) thread3).getMaximum();
            int max4 = ((MaximumFinderThread) thread4).getMaximum();


            int maximum = Math.max(Math.max(max1, max2), Math.max(max3, max4));

            System.out.println("Maximum number: " + maximum);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}

class MaximumFinderThread extends Thread {
    private int[] array;
    private int maximum;

    public MaximumFinderThread(int[] array) {
        this.array = array;
    }

    @Override
    public void run() {

        maximum = findMaximum(array);
    }

    private int findMaximum(int[] array) {
        int max = Integer.MIN_VALUE;
        for (int num : array) {
            max = Math.max(max, num);
        }
        return max;
    }

    public int getMaximum() {
        return maximum;
    }
}