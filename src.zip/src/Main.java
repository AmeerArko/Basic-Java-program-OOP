import java.awt.desktop.ScreenSleepEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Shape> shapes = new ArrayList<>();

        System.out.println("Press (1) for calculating Rectangle Area");
        System.out.println("Press (2) for calculating Square Area");
        System.out.println("Press (3) for calculating Circle Area");
        int choice = scanner.nextInt();


        Area rectangle = new Area();
        Area square = new Area();
        Area circle = new Area();

        shapes.add(rectangle);
        shapes.add(square);
        shapes.add(circle);

        switch (choice) {
            case 1:
                System.out.println("Enter length and breadth of rectangle:");
                double length = scanner.nextDouble();
                double breadth = scanner.nextDouble();
                rectangle.RectangleArea(length, breadth);
                System.out.println("Area of rectangle: " + rectangle.getArea());
                System.out.println(" ");


                break;
            case 2:
                System.out.println("Enter side of square:");
                double side = scanner.nextDouble();
                square.SquareArea(side);
                System.out.println("Area of square: " + square.getArea());
                System.out.println(" ");
                break;
            case 3:
                System.out.println("Enter radius of circle:");

                double radius = scanner.nextDouble();
                circle.CircleArea(radius);
                System.out.println("Area of circle: " + circle.getArea());
                System.out.println(" ");
                break;
            default:
                System.out.println("Invalid choice");
                System.out.println(" ");
        }
        System.out.println("\n Enter The number of player:");
        int n = scanner.nextInt();
        Player[] players = new Player[n];
        for (int i = 0; i < n; i++) {
            System.out.println("Enter the name and the score of a player"+(i+1)+":");
            String name = scanner.next();
            int score = scanner.nextInt();

            players[i] = new Player(name, score);
        }
        Arrays.sort(players);
        for (Player player : players) {
            System.out.println(player);
        }
    }
}
