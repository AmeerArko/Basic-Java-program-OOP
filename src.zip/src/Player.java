import java.util.Arrays;
import java.util.Scanner;

class Player implements Comparable<Player> {
    String name;
    int score;

    public Player(String name, int score) {
        this.name = name;
        this.score = score;
    }


    public int compareTo(Player b) {
        if (this.score != b.score) {
            return b.score - this.score;
        } else {
            return this.name.compareTo(b.name);
        }
    }

    public String toString() {
        return name + " " + score;
    }
}


