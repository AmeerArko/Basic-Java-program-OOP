

abstract class Shape {
    private double area;

    public double getArea() {
        return area;
    }

    public void setArea(double area) {
        this.area = area;
    }

    abstract void RectangleArea(double length, double breadth);

    abstract void SquareArea(double side);

    abstract void CircleArea(double radius);
}

class Area extends Shape {

    void RectangleArea(double length, double breadth) {
        setArea(length * breadth);
    }


    void SquareArea(double side) {
        setArea(side * side);
    }


    void CircleArea(double radius) {
        setArea(3.1416 * radius * radius);
    }
}

